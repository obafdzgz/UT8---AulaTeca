package aulateca.view;

import aulateca.model.User;
import aulateca.service.UserService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginView extends JFrame {

    // Componentes de la interfaz
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;

    // Conexión con la capa de negocio
    private final UserService userService = new UserService();

    public LoginView() {
        // Configuración básica de la ventana
        setTitle("Aulateca - Inicio de Sesión");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centra la ventana en la pantalla
        setResizable(false);

        // Crear el panel principal con un diseño ordenado
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Margen entre componentes
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // 1. Etiqueta y campo de Usuario
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Usuario:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        txtUsername = new JTextField(15);
        panel.add(txtUsername, gbc);

        // 2. Etiqueta y campo de Contraseña
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Contraseña:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        // no se ven los caracteres de la clave
        txtPassword = new JPasswordField(15);
        panel.add(txtPassword, gbc);

        // 3. Botón de acceder
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2; // Ocupa las dos columnas
        btnLogin = new JButton("Iniciar Sesión");
        panel.add(btnLogin, gbc);

        // Añadir el panel a la ventana
        add(panel);

        // Asignar la acción al botón (Controlador integrado para simplificar)
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                procesarLogin();
            }
        });
    }

    /**
     * Captura los datos de la pantalla y llama al servicio aplicando el control de excepciones
     */
    private void procesarLogin() {
        String username = txtUsername.getText();
        String password = new String(txtPassword.getPassword());

        try {
            // Llamamos a la lógica de negocio que programamos ayer
            User userLogueado = userService.login(username, password);

            // Si el login es correcto:
            // JOptionPane --> muestra el error
            JOptionPane.showMessageDialog(this, "¡Bienvenido, " + userLogueado.getUsername() + "!",
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);

            // TODO: Aquí abriremos la Ventana Principal mañana
            // MainView main = new MainView(userLogueado);
            // main.setVisible(true);

            this.dispose(); // Cierra la pantalla de login

        } catch (IllegalArgumentException ex) {
            // Captura los errores de campos vacíos, usuario no existente o contraseña incorrecta
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error de Autenticación", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Metodo main provisional para poder probar la pantalla directamente

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LoginView().setVisible(true);
        });
    }
}